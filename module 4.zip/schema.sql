-- Run this once in Supabase: SQL Editor > New query > paste > Run.
-- User credentials are handled by Supabase Auth (passwords are hashed; you never store them yourself).

create table if not exists public.posts (
  id           uuid primary key default gen_random_uuid(),
  author_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  author_email text default (auth.jwt() ->> 'email'),
  title        text not null check (char_length(title) between 1 and 200),
  content      text not null,
  category     text not null default 'General',
  created_at   timestamptz not null default now()
);

alter table public.posts enable row level security;

-- Anyone can read blogs
create policy "Public can read posts"
  on public.posts for select using (true);

-- Only logged-in users can create posts, and only as themselves
create policy "Users can create own posts"
  on public.posts for insert to authenticated
  with check (auth.uid() = author_id);

-- Users can edit or delete only their own posts
create policy "Users can update own posts"
  on public.posts for update to authenticated
  using (auth.uid() = author_id) with check (auth.uid() = author_id);

create policy "Users can delete own posts"
  on public.posts for delete to authenticated
  using (auth.uid() = author_id);

-- If you already ran the first version of this file, run just this line to add categories:
-- alter table public.posts add column if not exists category text not null default 'General';
